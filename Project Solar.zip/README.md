# Project-Solar
A data visualization web app for a small solar panel setup 
